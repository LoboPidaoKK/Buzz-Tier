# BuzzTier v1.20

**Rank · Organize · Compare**

O BuzzTier reúne três formatos: Tier List tradicional, Ranking List e **Esse ou Esse**.

## v1.20
- O botão `+` oferece Criar Tier Comum, Criar Ranking List e Esse ou Esse.
- Cada Tier List tem um único botão ON/OFF para decidir se seus personagens classificados participam do Esse ou Esse.
- O sorteio usa imagens de todos os níveis das Tier Lists ativadas; exclui capas, bandeja e Ranking Lists.
- Ranking List tem modo compacto e modo visual.

## Publicar
O repositório mantém `BuzzTier.zip` na raiz. O GitHub Actions extrai o ZIP, confere se ele é realmente a v1.20, publica os arquivos e gera o artefato `BuzzTier-v1.20-ZIP`.

1. Substitua `BuzzTier.zip` pelo pacote v1.20.
2. Substitua `.github/workflows/deploy.yml` pelo workflow v1.20.
3. Faça commit na branch `main`.
4. Em **Settings → Pages → Build and deployment → Source**, deixe **GitHub Actions**.
5. Em **Actions**, confirme que `Validar BuzzTier v1.20 e preparar site` e `Publicar BuzzTier v1.20` terminam verdes.

Site: https://lobopidaokk.github.io/Buzz-Tier/

## Dados
Tier Lists e Ranking Lists são salvas localmente no IndexedDB do navegador/dispositivo. Faça backup JSON antes de limpar os dados ou trocar de aparelho.
