<div align="center">
  <img src="icon.png" alt="Ícone do BuzzTier" width="112" height="112" />
  <h1>BuzzTier v1.19</h1>
  <p><strong>Rank · Organize · Compare</strong></p>
  <p>Crie Tier Lists tradicionais e Ranking Lists com imagens, nomes e posições reordenáveis.</p>
</div>

---

## Novidades da versão 1.19

- O botão **+** agora oferece a terceira opção **Esse ou Esse**.
- Cada tier de uma Tier List possui um botão vermelho (OFF) ou verde (ON) para decidir se suas imagens participam do sorteio.
- O Esse ou Esse usa exclusivamente imagens que já estão classificadas dentro das tiers ativadas. Capas, bandeja de não classificadas e Ranking Lists não entram no sorteio.
- Duas imagens diferentes são sorteadas para cada rodada. Ao escolher uma, ela recebe um contorno verde e o BuzzTier gera automaticamente um screenshot PNG da disputa com a vencedora destacada.
- O botão **Sortear próximo par** inicia outra comparação sem sair da ferramenta.
- No Android, o PNG é baixado pelo navegador; dependendo do navegador e das permissões, ele aparece em Downloads e pode ser exibido na Galeria. O site não grava silenciosamente no armazenamento privado da Galeria.

## O que há na v1.19

- **Criar Tier Comum:** mantém o editor tradicional de tiers, imagens e cores.
- **Criar Ranking List:** cada entrada tem imagem, nome e posição numerada automaticamente.
- **Dois modos de Ranking List:** compacto ou visual, com imagem grande e nome abaixo. A preferência é salva por lista.
- **Ordenação:** arraste itens para mudar suas posições; a numeração é recalculada automaticamente.
- **Capas personalizadas:** escolha capas para cada lista, sem selo redundante sobre a imagem.
- **Bandeja expandível:** imagens não classificadas em grade de cinco colunas e rolagem vertical.
- **Screenshot PNG:** a exportação permite escolher de 3 a 15 imagens por linha.
- **Backup e restauração:** listas e imagens são armazenadas no IndexedDB local.
- **PWA:** instalável pelo navegador e com cache offline após a primeira visita.

## Publicar no GitHub Pages usando somente BuzzTier.zip

O repositório pode manter o site compactado em um único arquivo na raiz. O workflow `.github/workflows/deploy.yml` extrai o ZIP, valida os arquivos necessários, publica o site e gera um artefato ZIP da versão.

### Atualizar o site

1. Faça um backup JSON das listas antes de trocar a versão.
2. Substitua `BuzzTier.zip` na raiz do repositório pelo pacote v1.19.
3. Substitua também `.github/workflows/deploy.yml` pelo workflow que acompanha esta versão. Isso é importante: o workflow antigo copiava arquivos diretamente da raiz e não extraía o ZIP.
4. Faça commit na branch `main`.
5. Em **Settings → Pages → Build and deployment → Source**, confirme **GitHub Actions**.
6. Abra **Actions** e confira a execução **Gerar ZIP e publicar Buzz-Tier**. Os trabalhos de preparação e publicação devem terminar com sucesso.
7. O artefato `BuzzTier-v1.19-ZIP` fica disponível na seção *Artifacts* da execução.

O site será publicado em:

`https://lobopidaokk.github.io/Buzz-Tier/`

## Seus dados

As listas ficam no IndexedDB do navegador/dispositivo. O GitHub Pages não sincroniza os dados entre aparelhos. Não limpe os dados do navegador para atualizar o site; use Backup JSON antes de atualizar ou trocar de dispositivo.

As listas antigas sem o campo `kind` continuam sendo interpretadas como Tier Lists comuns.

---

Feito com 💜 por Mika · BuzzTier v1.19
